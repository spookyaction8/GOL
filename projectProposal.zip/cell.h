//Zachary Teutsch
//
//CSCI 1300
//
//Conway's Game of Life
//Cell Header

#ifndef CELL_H
#define CELL_H

class cell{

	public:
		
		//constructors
		cell();
		cell(bool);
		~cell();

		//functions

		//currState set and getters
		bool getCurrState();
		void switchCurrState();

		//currState set and getters
		bool getNextState();
		bool switchNextState();


		bool nextGeneration();
		//determines the state of cell in next stage


	private:

		bool currentState;
		bool nextState;


};



#endif CELL_H

/*
	Cell Rules:

	1. Fewer than 2 alive neighbors, cell dies

	2. 2 alive neighbors, cell survives

	3. 3 alive neighbors, cell either a) survives b) comes alive

	4. More than 3 alive neighbors, cell dies

/*