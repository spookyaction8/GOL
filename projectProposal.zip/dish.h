//Zachary Teutsch
//
//CSCI 1300
//
//Conway's Game of Life
//Dish Header

#ifndef DISH_H
#define DISH_H

#include "cell.h"

class dish{

	public:

		//constructors

		dish();
		dish(int);
		dish(int, int);
		~dish();

		//functions

		bool advance();
		//advances to the next stage
		bool advance(int);
		//advances an integer number of stages

		//bool autoAdvance();

		void printDish();
		//prints representation of the dish to console

		//setters
		void setX(int);
		void setY(int);
		void setLiveChar(char);
		void setDeadChar(char);

		//getters
		int getX();
		int getY();
		char getLiveChar();
		char getDeadChar();
		int currGeneration();
		int getNumCells();

		//writes and loads state data to a file
		
		bool savedDishState(string);
		bool loadDishState(string);

		//possible function call(s) for predetermined start state

	private:

		int sizeX;
		int sizeY;

		cell dishState[sizeY][sizeX];

		int numCells;

		int currGeneration;

		char liveChar;
		char deadChar;


};




#endif DISH_H